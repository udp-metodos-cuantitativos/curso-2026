############################################################
# PROCESAMIENTO Y VISUALIZACIÓN DE DATOS EN R
# AYUDANTÍA 1 - SCRIPT 02
#
# Galería compacta de tablas, gráficos y salidas exportables
#
# Versión ajustada para usar la base con estas variables:
# id
# edad
# genero
# zona_residencia
# situacion_laboral
# transporte_principal
# tiempo_traslado_min
# horas_sueno
# actividad_fisica_sem
# horas_redes_dia
# participacion_social
# confianza_vecinal
# estres_cotidiano
# bienestar_general
# satisfaccion_tiempo_libre
#
# Tema:
# Movilidad cotidiana, uso del tiempo, bienestar y vida adulta.
############################################################


############################################################
# 0. LIMPIEZA DEL ENTORNO
############################################################

rm(list = ls())
options(scipen = 999)


############################################################
# 1. CARGA DE PAQUETES
############################################################

if (!require(pacman)) {
  install.packages("pacman")
}

pacman::p_load(
  tidyverse,
  ggplot2,
  scales,
  janitor,
  gt,
  gtsummary,
  openxlsx,
  patchwork,
  gridExtra
)


############################################################
# 2. CREAR CARPETAS DE SALIDA
############################################################

dir.create("input/data", showWarnings = FALSE, recursive = TRUE)
dir.create("output", showWarnings = FALSE, recursive = TRUE)
dir.create("output/graficos", showWarnings = FALSE, recursive = TRUE)
dir.create("output/tablas", showWarnings = FALSE, recursive = TRUE)
dir.create("output/tablas/html", showWarnings = FALSE, recursive = TRUE)
dir.create("output/tablas/png", showWarnings = FALSE, recursive = TRUE)
dir.create("output/tablas/excel", showWarnings = FALSE, recursive = TRUE)
dir.create("output/tablas/csv", showWarnings = FALSE, recursive = TRUE)


############################################################
# 3. CARGAR BASE
############################################################

# Ruta esperada del archivo CSV.
# Cambia esta ruta solamente si tu archivo tiene otro nombre o está en otra carpeta.

archivo_csv <- "input/data/base_practica_movilidad_bienestar.csv"

if (file.exists(archivo_csv)) {
  
  datos_proc <- read_csv(
    archivo_csv,
    show_col_types = FALSE
  )
  
} else {
  
  stop(
    paste0(
      "No se encontró el archivo CSV en la ruta: ",
      archivo_csv,
      "\nGuarda tu base en esa ruta o modifica el objeto archivo_csv."
    )
  )
}

# Revisión rápida de la base.

names(datos_proc)
dim(datos_proc)
summary(datos_proc)


############################################################
# 4. VERIFICAR VARIABLES NECESARIAS
############################################################

variables_necesarias <- c(
  "id",
  "edad",
  "genero",
  "zona_residencia",
  "situacion_laboral",
  "transporte_principal",
  "tiempo_traslado_min",
  "horas_sueno",
  "actividad_fisica_sem",
  "horas_redes_dia",
  "participacion_social",
  "confianza_vecinal",
  "estres_cotidiano",
  "bienestar_general",
  "satisfaccion_tiempo_libre"
)

variables_faltantes <- setdiff(variables_necesarias, names(datos_proc))

if (length(variables_faltantes) > 0) {
  stop(
    paste(
      "Faltan estas variables en la base:",
      paste(variables_faltantes, collapse = ", ")
    )
  )
}


############################################################
# 5. ASEGURAR TIPOS DE VARIABLES
############################################################

# Esta función ayuda a convertir variables a número aunque vengan como texto.

convertir_numero <- function(x) {
  suppressWarnings(as.numeric(x))
}

vars_numericas <- c(
  "id",
  "edad",
  "zona_residencia",
  "situacion_laboral",
  "transporte_principal",
  "tiempo_traslado_min",
  "horas_sueno",
  "actividad_fisica_sem",
  "horas_redes_dia",
  "participacion_social",
  "confianza_vecinal",
  "estres_cotidiano",
  "bienestar_general",
  "satisfaccion_tiempo_libre"
)

datos_proc <- datos_proc %>%
  mutate(
    across(
      all_of(vars_numericas),
      convertir_numero
    ),
    genero = as.character(genero)
  )


############################################################
# 6. CREAR VARIABLES CATEGÓRICAS PARA TABLAS Y GRÁFICOS
############################################################

# IMPORTANTE:
# Las etiquetas de zona, situación laboral y transporte son supuestos
# razonables para una base de práctica.
# Si tu cuestionario usa otra codificación, edita los textos de case_when().

datos_proc <- datos_proc %>%
  mutate(
    
    ########################################################
    # 6.1 Zona de residencia
    ########################################################
    
    zona_cat = case_when(
      zona_residencia == 1 ~ "Urbana",
      zona_residencia == 2 ~ "Rural",
      TRUE ~ paste0("Código ", zona_residencia)
    ),
    
    ########################################################
    # 6.2 Situación laboral
    ########################################################
    
    situacion_laboral_cat = case_when(
      situacion_laboral == 1 ~ "Trabaja",
      situacion_laboral == 2 ~ "Estudia",
      situacion_laboral == 3 ~ "Trabaja y estudia",
      situacion_laboral == 4 ~ "No trabaja",
      situacion_laboral == 5 ~ "Otra situación",
      TRUE ~ paste0("Código ", situacion_laboral)
    ),
    
    ########################################################
    # 6.3 Transporte principal
    ########################################################
    
    transporte_cat = case_when(
      transporte_principal == 1 ~ "Transporte público",
      transporte_principal == 2 ~ "Auto o moto",
      transporte_principal == 3 ~ "Bicicleta",
      transporte_principal == 4 ~ "Caminata",
      transporte_principal == 5 ~ "Otro transporte",
      TRUE ~ paste0("Código ", transporte_principal)
    ),
    
    ########################################################
    # 6.4 Participación social
    ########################################################
    
    participacion_cat = case_when(
      participacion_social %in% c(1, 2) ~ "Baja",
      participacion_social == 3 ~ "Media",
      participacion_social %in% c(4, 5) ~ "Alta",
      TRUE ~ NA_character_
    ),
    
    ########################################################
    # 6.5 Confianza vecinal
    ########################################################
    
    confianza_cat = case_when(
      confianza_vecinal %in% c(1, 2) ~ "Baja",
      confianza_vecinal == 3 ~ "Media",
      confianza_vecinal %in% c(4, 5) ~ "Alta",
      TRUE ~ NA_character_
    ),
    
    ########################################################
    # 6.6 Estrés cotidiano
    ########################################################
    
    estres_cat = case_when(
      estres_cotidiano == 1 ~ "Muy bajo",
      estres_cotidiano == 2 ~ "Bajo",
      estres_cotidiano == 3 ~ "Medio",
      estres_cotidiano == 4 ~ "Alto",
      estres_cotidiano == 5 ~ "Muy alto",
      TRUE ~ NA_character_
    ),
    
    ########################################################
    # 6.7 Satisfacción con el tiempo libre
    ########################################################
    
    satisfaccion_tiempo_cat = case_when(
      satisfaccion_tiempo_libre == 1 ~ "Muy baja",
      satisfaccion_tiempo_libre == 2 ~ "Baja",
      satisfaccion_tiempo_libre == 3 ~ "Media",
      satisfaccion_tiempo_libre == 4 ~ "Alta",
      satisfaccion_tiempo_libre == 5 ~ "Muy alta",
      TRUE ~ NA_character_
    ),
    
    ########################################################
    # 6.8 Bienestar general
    ########################################################
    
    bienestar_cat = case_when(
      bienestar_general < 5 ~ "Bienestar bajo",
      bienestar_general >= 5 & bienestar_general < 7 ~ "Bienestar medio",
      bienestar_general >= 7 ~ "Bienestar alto",
      TRUE ~ NA_character_
    ),
    
    ########################################################
    # 6.9 Carga cotidiana por tiempo de traslado
    ########################################################
    
    carga_movilidad_tiempo = case_when(
      tiempo_traslado_min >= 60 ~ "Alta carga cotidiana",
      tiempo_traslado_min < 60 ~ "Carga moderada o baja",
      TRUE ~ NA_character_
    ),
    
    ########################################################
    # 6.10 Actividad física semanal
    ########################################################
    
    actividad_fisica_cat = case_when(
      actividad_fisica_sem < 3 ~ "Actividad baja",
      actividad_fisica_sem >= 3 ~ "Actividad moderada o alta",
      TRUE ~ NA_character_
    )
  )


############################################################
# 7. ORDENAR VARIABLES CATEGÓRICAS
############################################################

datos_proc <- datos_proc %>%
  mutate(
    genero = factor(genero),
    
    zona_cat = factor(
      zona_cat,
      levels = c("Urbana", "Rural")
    ),
    
    situacion_laboral_cat = factor(
      situacion_laboral_cat,
      levels = c(
        "Trabaja",
        "Estudia",
        "Trabaja y estudia",
        "No trabaja",
        "Otra situación"
      )
    ),
    
    transporte_cat = factor(
      transporte_cat,
      levels = c(
        "Transporte público",
        "Auto o moto",
        "Bicicleta",
        "Caminata",
        "Otro transporte"
      )
    ),
    
    participacion_cat = factor(
      participacion_cat,
      levels = c("Baja", "Media", "Alta"),
      ordered = TRUE
    ),
    
    confianza_cat = factor(
      confianza_cat,
      levels = c("Baja", "Media", "Alta"),
      ordered = TRUE
    ),
    
    estres_cat = factor(
      estres_cat,
      levels = c("Muy bajo", "Bajo", "Medio", "Alto", "Muy alto"),
      ordered = TRUE
    ),
    
    satisfaccion_tiempo_cat = factor(
      satisfaccion_tiempo_cat,
      levels = c("Muy baja", "Baja", "Media", "Alta", "Muy alta"),
      ordered = TRUE
    ),
    
    bienestar_cat = factor(
      bienestar_cat,
      levels = c("Bienestar bajo", "Bienestar medio", "Bienestar alto"),
      ordered = TRUE
    ),
    
    carga_movilidad_tiempo = factor(
      carga_movilidad_tiempo,
      levels = c("Carga moderada o baja", "Alta carga cotidiana")
    ),
    
    actividad_fisica_cat = factor(
      actividad_fisica_cat,
      levels = c("Actividad baja", "Actividad moderada o alta")
    )
  )


############################################################
# 8. GUARDAR BASE PROCESADA
############################################################

save(
  datos_proc,
  file = "output/datos_proc_final_movilidad_bienestar.RData"
)

write_csv(
  datos_proc,
  "output/datos_proc_final_movilidad_bienestar.csv"
)


############################################################
# 9. ESTILO GENERAL PARA GRÁFICOS
############################################################

theme_ayudantia <- function(base_size = 12) {
  theme_minimal(base_size = base_size) +
    theme(
      plot.title = element_text(face = "bold", size = base_size + 3),
      plot.subtitle = element_text(size = base_size, color = "gray30"),
      plot.caption = element_text(size = base_size - 2, color = "gray40"),
      axis.title = element_text(face = "bold"),
      axis.text.x = element_text(angle = 15, hjust = 1),
      panel.grid.minor = element_blank(),
      legend.title = element_text(face = "bold")
    )
}

crear_paleta <- function(x, preferidos = NULL) {
  
  categorias <- sort(unique(na.omit(as.character(x))))
  
  if (length(categorias) == 0) {
    return(character(0))
  }
  
  colores_base <- c(
    "#4E79A7",
    "#F28E2B",
    "#59A14F",
    "#E15759",
    "#76B7B2",
    "#EDC948",
    "#B07AA1",
    "#9C755F"
  )
  
  paleta <- setNames(
    rep(colores_base, length.out = length(categorias)),
    categorias
  )
  
  if (!is.null(preferidos)) {
    comunes <- intersect(names(preferidos), names(paleta))
    paleta[comunes] <- preferidos[comunes]
  }
  
  return(paleta)
}

pal_situacion <- crear_paleta(datos_proc$situacion_laboral_cat)

pal_carga <- crear_paleta(
  datos_proc$carga_movilidad_tiempo,
  preferidos = c(
    "Carga moderada o baja" = "#4E79A7",
    "Alta carga cotidiana" = "#E15759"
  )
)


############################################################
# 10. FUNCIONES AUXILIARES PARA GUARDAR TABLAS
############################################################

guardar_gt_html <- function(tabla_gt, archivo_html) {
  gt::gtsave(
    data = tabla_gt,
    filename = archivo_html
  )
}

guardar_tabla_png <- function(tabla,
                              archivo,
                              titulo = NULL,
                              width = 1600,
                              height = 900,
                              res = 200) {
  
  png(
    filename = archivo,
    width = width,
    height = height,
    res = res
  )
  
  grid::grid.newpage()
  
  tabla_grob <- gridExtra::tableGrob(
    tabla,
    rows = NULL,
    theme = gridExtra::ttheme_minimal(
      base_size = 9,
      core = list(
        fg_params = list(hjust = 0, x = 0.03)
      ),
      colhead = list(
        fg_params = list(fontface = "bold", col = "white"),
        bg_params = list(fill = "#2F3A45", col = NA)
      )
    )
  )
  
  if (!is.null(titulo)) {
    
    titulo_grob <- grid::textGrob(
      titulo,
      gp = grid::gpar(fontsize = 14, fontface = "bold")
    )
    
    grid::grid.draw(
      gridExtra::arrangeGrob(
        titulo_grob,
        tabla_grob,
        ncol = 1,
        heights = c(0.15, 0.85)
      )
    )
    
  } else {
    
    grid::grid.draw(tabla_grob)
  }
  
  dev.off()
}


############################################################
# 11. GALERÍA COMPACTA DE TABLAS PARA INFORMES
############################################################


############################################################
# 11.1 TABLA 1: RESUMEN EJECUTIVO
############################################################

tabla_01_resumen <- tibble(
  Indicador = c(
    "Total de personas",
    "Edad promedio",
    "% mujeres",
    "% zona urbana",
    "% alta carga cotidiana",
    "Promedio tiempo de traslado",
    "Promedio horas de sueño",
    "Promedio actividad física semanal",
    "Promedio horas en redes",
    "Promedio participación social",
    "Promedio confianza vecinal",
    "Promedio estrés cotidiano",
    "Bienestar promedio",
    "Satisfacción promedio con tiempo libre"
  ),
  
  Valor = c(
    nrow(datos_proc),
    mean(datos_proc$edad, na.rm = TRUE),
    mean(datos_proc$genero == "Mujer", na.rm = TRUE) * 100,
    mean(datos_proc$zona_cat == "Urbana", na.rm = TRUE) * 100,
    mean(datos_proc$carga_movilidad_tiempo == "Alta carga cotidiana", na.rm = TRUE) * 100,
    mean(datos_proc$tiempo_traslado_min, na.rm = TRUE),
    mean(datos_proc$horas_sueno, na.rm = TRUE),
    mean(datos_proc$actividad_fisica_sem, na.rm = TRUE),
    mean(datos_proc$horas_redes_dia, na.rm = TRUE),
    mean(datos_proc$participacion_social, na.rm = TRUE),
    mean(datos_proc$confianza_vecinal, na.rm = TRUE),
    mean(datos_proc$estres_cotidiano, na.rm = TRUE),
    mean(datos_proc$bienestar_general, na.rm = TRUE),
    mean(datos_proc$satisfaccion_tiempo_libre, na.rm = TRUE)
  )
) %>%
  mutate(Valor = round(Valor, 2))

tabla_01_gt <- tabla_01_resumen %>%
  gt() %>%
  tab_header(
    title = md("**Resumen ejecutivo de la muestra**"),
    subtitle = "Indicadores principales sobre movilidad, uso del tiempo, vida social y bienestar"
  ) %>%
  fmt_number(
    columns = Valor,
    decimals = 2
  ) %>%
  cols_label(
    Indicador = "Indicador",
    Valor = "Valor"
  ) %>%
  tab_source_note(
    source_note = "Fuente: base de práctica de ayudantía."
  ) %>%
  tab_options(
    table.font.names = "Arial",
    heading.title.font.size = 16,
    heading.subtitle.font.size = 12,
    column_labels.font.weight = "bold"
  )

tabla_01_gt

guardar_gt_html(
  tabla_gt = tabla_01_gt,
  archivo_html = "output/tablas/html/tabla_01_resumen_muestra.html"
)

guardar_tabla_png(
  tabla = tabla_01_resumen,
  archivo = "output/tablas/png/tabla_01_resumen_muestra.png",
  titulo = "Resumen ejecutivo de la muestra",
  width = 1700,
  height = 950
)


############################################################
# 11.2 TABLA 2: FRECUENCIA SIMPLE
############################################################

tabla_02_frecuencia <- datos_proc %>%
  filter(!is.na(situacion_laboral_cat)) %>%
  janitor::tabyl(situacion_laboral_cat) %>%
  as_tibble() %>%
  transmute(
    Categoria = situacion_laboral_cat,
    Frecuencia = n,
    Porcentaje = round(percent * 100, 1),
    Etiqueta = paste0(n, " casos\n", round(percent * 100, 1), "%")
  )

graf_tabla_02 <- ggplot(
  tabla_02_frecuencia,
  aes(x = Categoria, y = Porcentaje / 100, fill = Categoria)
) +
  geom_col(width = 0.6) +
  geom_text(
    aes(label = Etiqueta),
    vjust = -0.3,
    size = 4
  ) +
  scale_y_continuous(
    labels = percent_format(),
    expand = expansion(mult = c(0, 0.15))
  ) +
  scale_fill_manual(values = pal_situacion) +
  labs(
    title = "Situación laboral de las personas encuestadas",
    subtitle = "Frecuencia y porcentaje por categoría",
    x = "Situación laboral",
    y = "Porcentaje",
    caption = "Fuente: base de práctica de ayudantía."
  ) +
  theme_ayudantia() +
  theme(legend.position = "none")

graf_tabla_02

ggsave(
  filename = "output/tablas/png/tabla_02_frecuencia_situacion_laboral_grafica.png",
  plot = graf_tabla_02,
  width = 9,
  height = 5.5,
  dpi = 300
)


############################################################
# 11.3 TABLA 3: BIENESTAR ORDINAL CON ACUMULADO
############################################################

tabla_03_ordinal <- datos_proc %>%
  filter(!is.na(bienestar_cat)) %>%
  count(bienestar_cat, name = "Frecuencia") %>%
  mutate(
    Porcentaje = Frecuencia / sum(Frecuencia) * 100,
    `Porcentaje acumulado` = cumsum(Porcentaje),
    Porcentaje = round(Porcentaje, 1),
    `Porcentaje acumulado` = round(`Porcentaje acumulado`, 1)
  ) %>%
  rename(
    `Nivel de bienestar` = bienestar_cat
  )

tabla_03_gt <- tabla_03_ordinal %>%
  gt() %>%
  tab_header(
    title = md("**Distribución ordinal del bienestar general**"),
    subtitle = "Frecuencia, porcentaje y porcentaje acumulado"
  ) %>%
  fmt_number(
    columns = c(Porcentaje, `Porcentaje acumulado`),
    decimals = 1
  ) %>%
  tab_source_note(
    source_note = "Fuente: base de práctica de ayudantía."
  ) %>%
  tab_options(
    table.font.names = "Arial",
    heading.title.font.size = 16,
    heading.subtitle.font.size = 12,
    column_labels.font.weight = "bold"
  )

tabla_03_gt

guardar_gt_html(
  tabla_gt = tabla_03_gt,
  archivo_html = "output/tablas/html/tabla_03_bienestar_acumulado.html"
)

guardar_tabla_png(
  tabla = tabla_03_ordinal,
  archivo = "output/tablas/png/tabla_03_bienestar_acumulado.png",
  titulo = "Distribución ordinal del bienestar general",
  width = 1600,
  height = 800
)


############################################################
# 11.4 TABLA 4: DESCRIPTIVOS POR SITUACIÓN LABORAL
############################################################

tabla_04_descriptivos <- datos_proc %>%
  filter(!is.na(situacion_laboral_cat)) %>%
  group_by(situacion_laboral_cat) %>%
  summarise(
    N = n(),
    `Media edad` = mean(edad, na.rm = TRUE),
    `Media traslado` = mean(tiempo_traslado_min, na.rm = TRUE),
    `Media sueño` = mean(horas_sueno, na.rm = TRUE),
    `Media actividad física` = mean(actividad_fisica_sem, na.rm = TRUE),
    `Media redes` = mean(horas_redes_dia, na.rm = TRUE),
    `Media participación` = mean(participacion_social, na.rm = TRUE),
    `Media confianza` = mean(confianza_vecinal, na.rm = TRUE),
    `Media estrés` = mean(estres_cotidiano, na.rm = TRUE),
    `Media bienestar` = mean(bienestar_general, na.rm = TRUE),
    `Media satisfacción tiempo libre` = mean(satisfaccion_tiempo_libre, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  rename(
    `Situación laboral` = situacion_laboral_cat
  )

tabla_04_gt <- tabla_04_descriptivos %>%
  gt() %>%
  tab_header(
    title = md("**Descriptivos según situación laboral**"),
    subtitle = "Edad, movilidad, descanso, redes, vida social, estrés y bienestar"
  ) %>%
  fmt_number(
    columns = where(is.numeric),
    decimals = 2
  ) %>%
  tab_source_note(
    source_note = "Fuente: base de práctica de ayudantía."
  ) %>%
  tab_options(
    table.font.names = "Arial",
    heading.title.font.size = 16,
    heading.subtitle.font.size = 12,
    column_labels.font.weight = "bold"
  )

tabla_04_gt

guardar_gt_html(
  tabla_gt = tabla_04_gt,
  archivo_html = "output/tablas/html/tabla_04_descriptivos_por_situacion_laboral.html"
)

guardar_tabla_png(
  tabla = tabla_04_descriptivos,
  archivo = "output/tablas/png/tabla_04_descriptivos_por_situacion_laboral.png",
  titulo = "Descriptivos según situación laboral",
  width = 2600,
  height = 900
)


############################################################
# 11.5 TABLA 5: CRUCE ENTRE CARGA COTIDIANA Y BIENESTAR
############################################################

tabla_05_cruce_larga <- datos_proc %>%
  filter(!is.na(carga_movilidad_tiempo), !is.na(bienestar_cat)) %>%
  count(
    carga_movilidad_tiempo,
    bienestar_cat,
    name = "Frecuencia",
    .drop = FALSE
  ) %>%
  group_by(carga_movilidad_tiempo) %>%
  mutate(
    Porcentaje = Frecuencia / sum(Frecuencia),
    Etiqueta = paste0(Frecuencia, "\n(", percent(Porcentaje, accuracy = 0.1), ")")
  ) %>%
  ungroup()

graf_tabla_05 <- ggplot(
  tabla_05_cruce_larga,
  aes(x = bienestar_cat, y = carga_movilidad_tiempo, fill = Porcentaje)
) +
  geom_tile(color = "white", linewidth = 1) +
  geom_text(aes(label = Etiqueta), size = 4) +
  scale_fill_gradient(
    low = "#F7FBFF",
    high = "#4E79A7",
    labels = percent_format()
  ) +
  labs(
    title = "Bienestar general según carga cotidiana",
    subtitle = "Cada celda muestra frecuencia y porcentaje por fila",
    x = "Nivel de bienestar",
    y = "Carga cotidiana",
    fill = "% por fila",
    caption = "Fuente: base de práctica de ayudantía."
  ) +
  theme_ayudantia() +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 0.5),
    panel.grid = element_blank()
  )

graf_tabla_05

ggsave(
  filename = "output/tablas/png/tabla_05_cruce_carga_bienestar_mapa.png",
  plot = graf_tabla_05,
  width = 9,
  height = 5,
  dpi = 300
)

tabla_05_cruce_excel <- tabla_05_cruce_larga %>%
  mutate(
    Celda = paste0(Frecuencia, " (", percent(Porcentaje, accuracy = 0.1), ")")
  ) %>%
  select(carga_movilidad_tiempo, bienestar_cat, Celda) %>%
  pivot_wider(
    names_from = bienestar_cat,
    values_from = Celda
  ) %>%
  rename(
    `Carga cotidiana` = carga_movilidad_tiempo
  )


############################################################
# 11.6 TABLA 6: TABLA TIPO ARTÍCULO
############################################################

tabla_06_articulo <- datos_proc %>%
  select(
    situacion_laboral_cat,
    genero,
    edad,
    zona_cat,
    transporte_cat,
    tiempo_traslado_min,
    horas_sueno,
    actividad_fisica_sem,
    horas_redes_dia,
    actividad_fisica_cat,
    participacion_cat,
    confianza_cat,
    estres_cat,
    bienestar_general,
    bienestar_cat,
    satisfaccion_tiempo_cat,
    carga_movilidad_tiempo
  ) %>%
  tbl_summary(
    by = situacion_laboral_cat,
    statistic = list(
      all_continuous() ~ "{mean} ({sd})",
      all_categorical() ~ "{n} ({p}%)"
    ),
    digits = all_continuous() ~ 2,
    missing = "no"
  ) %>%
  add_overall() %>%
  modify_header(
    label ~ "**Variable**"
  ) %>%
  modify_caption(
    "**Tabla descriptiva de la muestra según situación laboral**"
  )

tabla_06_articulo

tabla_06_articulo_gt <- as_gt(tabla_06_articulo)

guardar_gt_html(
  tabla_gt = tabla_06_articulo_gt,
  archivo_html = "output/tablas/html/tabla_06_gtsummary_articulo.html"
)

tabla_06_articulo_excel <- tryCatch(
  {
    as_tibble(tabla_06_articulo, col_labels = TRUE)
  },
  error = function(e) {
    tabla_06_articulo$table_body
  }
) %>%
  mutate(across(everything(), as.character))


############################################################
# 11.7 CSV DE EJEMPLO
############################################################

write_csv(
  tabla_01_resumen,
  "output/tablas/csv/tabla_01_resumen_muestra_ejemplo.csv"
)


############################################################
# 11.8 EXCEL FINAL CON TODAS LAS TABLAS BASE
############################################################

wb <- createWorkbook()

estilo_header <- createStyle(
  textDecoration = "bold",
  fontColour = "white",
  fgFill = "#2F3A45",
  halign = "center"
)

agregar_hoja <- function(wb, hoja, tabla) {
  
  addWorksheet(wb, hoja)
  
  writeDataTable(
    wb,
    sheet = hoja,
    x = tabla,
    startRow = 1,
    startCol = 1,
    tableStyle = "TableStyleMedium2",
    withFilter = TRUE
  )
  
  addStyle(
    wb,
    sheet = hoja,
    style = estilo_header,
    rows = 1,
    cols = 1:ncol(tabla),
    gridExpand = TRUE
  )
  
  setColWidths(
    wb,
    sheet = hoja,
    cols = 1:ncol(tabla),
    widths = "auto"
  )
  
  freezePane(
    wb,
    sheet = hoja,
    firstActiveRow = 2
  )
}

agregar_hoja(wb, "Resumen", tabla_01_resumen)
agregar_hoja(wb, "Frecuencia", tabla_02_frecuencia)
agregar_hoja(wb, "Ordinal", tabla_03_ordinal)
agregar_hoja(wb, "Descriptivos", tabla_04_descriptivos)
agregar_hoja(wb, "Cruce", tabla_05_cruce_excel)
agregar_hoja(wb, "Articulo", tabla_06_articulo_excel)

saveWorkbook(
  wb,
  file = "output/tablas/excel/galeria_tablas_ayudantia.xlsx",
  overwrite = TRUE
)

############################################################
# 12. GALERÍA COMPACTA DE VISUALIZACIONES
############################################################

# Antes de graficar, creamos una base especial para gráficos.
# Esto NO modifica la base original datos_proc.
# Solo evita que valores inválidos como 999, 1000 o -99
# arruinen las escalas visuales.

datos_graf <- datos_proc %>%
  mutate(
    edad = if_else(edad >= 15 & edad <= 90, edad, NA_real_),
    tiempo_traslado_min = if_else(
      tiempo_traslado_min >= 0 & tiempo_traslado_min <= 240,
      tiempo_traslado_min,
      NA_real_
    ),
    horas_sueno = if_else(
      horas_sueno >= 0 & horas_sueno <= 14,
      horas_sueno,
      NA_real_
    ),
    actividad_fisica_sem = if_else(
      actividad_fisica_sem >= 0 & actividad_fisica_sem <= 21,
      actividad_fisica_sem,
      NA_real_
    ),
    horas_redes_dia = if_else(
      horas_redes_dia >= 0 & horas_redes_dia <= 16,
      horas_redes_dia,
      NA_real_
    ),
    participacion_social = if_else(
      participacion_social >= 1 & participacion_social <= 5,
      participacion_social,
      NA_real_
    ),
    confianza_vecinal = if_else(
      confianza_vecinal >= 1 & confianza_vecinal <= 5,
      confianza_vecinal,
      NA_real_
    ),
    estres_cotidiano = if_else(
      estres_cotidiano >= 1 & estres_cotidiano <= 5,
      estres_cotidiano,
      NA_real_
    ),
    bienestar_general = if_else(
      bienestar_general >= 0 & bienestar_general <= 10,
      bienestar_general,
      NA_real_
    ),
    satisfaccion_tiempo_libre = if_else(
      satisfaccion_tiempo_libre >= 1 & satisfaccion_tiempo_libre <= 10,
      satisfaccion_tiempo_libre,
      NA_real_
    )
  ) %>%
  mutate(
    bienestar_cat = case_when(
      bienestar_general < 5 ~ "Bienestar bajo",
      bienestar_general >= 5 & bienestar_general < 7 ~ "Bienestar medio",
      bienestar_general >= 7 ~ "Bienestar alto",
      TRUE ~ NA_character_
    ),
    bienestar_cat = factor(
      bienestar_cat,
      levels = c("Bienestar bajo", "Bienestar medio", "Bienestar alto"),
      ordered = TRUE
    ),
    carga_movilidad_tiempo = case_when(
      tiempo_traslado_min >= 60 ~ "Alta carga cotidiana",
      tiempo_traslado_min < 60 ~ "Carga moderada o baja",
      TRUE ~ NA_character_
    ),
    carga_movilidad_tiempo = factor(
      carga_movilidad_tiempo,
      levels = c("Carga moderada o baja", "Alta carga cotidiana")
    )
  )

# Paletas actualizadas según la base limpia para gráficos.

pal_situacion_graf <- crear_paleta(datos_graf$situacion_laboral_cat)

pal_carga_graf <- crear_paleta(
  datos_graf$carga_movilidad_tiempo,
  preferidos = c(
    "Carga moderada o baja" = "#4E79A7",
    "Alta carga cotidiana" = "#E15759"
  )
)


############################################################
# 12.1 GRÁFICO 1: BARRAS CON PORCENTAJE
############################################################

datos_graf_01 <- datos_graf %>%
  filter(!is.na(situacion_laboral_cat))

n_graf_01 <- nrow(datos_graf_01)

graf_01_barras <- datos_graf_01 %>%
  count(situacion_laboral_cat) %>%
  mutate(
    porcentaje = n / sum(n),
    etiqueta = paste0(n, "\n", percent(porcentaje, accuracy = 0.1))
  ) %>%
  ggplot(aes(x = situacion_laboral_cat, y = porcentaje, fill = situacion_laboral_cat)) +
  geom_col(width = 0.65) +
  geom_text(
    aes(label = etiqueta),
    vjust = -0.35,
    size = 4
  ) +
  scale_y_continuous(
    labels = percent_format(),
    limits = c(0, NA),
    expand = expansion(mult = c(0, 0.18))
  ) +
  scale_fill_manual(values = pal_situacion_graf) +
  labs(
    title = "Distribución según situación laboral",
    subtitle = paste0("Porcentaje de personas por categoría. N válido = ", n_graf_01),
    x = "Situación laboral",
    y = "Porcentaje",
    caption = "Fuente: base de práctica de ayudantía."
  ) +
  theme_ayudantia() +
  theme(legend.position = "none")

graf_01_barras

ggsave(
  filename = "output/graficos/01_barras_situacion_laboral_porcentaje.png",
  plot = graf_01_barras,
  width = 9,
  height = 5.5,
  dpi = 300
)


############################################################
# 12.2 GRÁFICO 2: HISTOGRAMA CON MEDIA
############################################################

datos_graf_02 <- datos_graf %>%
  filter(!is.na(bienestar_general))

n_graf_02 <- nrow(datos_graf_02)
media_bienestar <- mean(datos_graf_02$bienestar_general, na.rm = TRUE)

graf_02_histograma <- datos_graf_02 %>%
  ggplot(aes(x = bienestar_general)) +
  geom_histogram(
    binwidth = 1,
    boundary = 0,
    fill = "#4E79A7",
    color = "white"
  ) +
  geom_vline(
    xintercept = media_bienestar,
    linetype = "dashed",
    linewidth = 1
  ) +
  annotate(
    "text",
    x = media_bienestar,
    y = Inf,
    label = paste0("Media = ", round(media_bienestar, 2)),
    vjust = 1.5,
    hjust = -0.1,
    size = 4
  ) +
  scale_x_continuous(
    limits = c(0, 10),
    breaks = 0:10
  ) +
  labs(
    title = "Distribución del bienestar general",
    subtitle = paste0("Escala válida de 0 a 10. N válido = ", n_graf_02),
    x = "Bienestar general",
    y = "Frecuencia",
    caption = "Fuente: base de práctica de ayudantía."
  ) +
  theme_ayudantia()

graf_02_histograma

ggsave(
  filename = "output/graficos/02_histograma_bienestar_general.png",
  plot = graf_02_histograma,
  width = 8,
  height = 5,
  dpi = 300
)


############################################################
# 12.3 GRÁFICO 3: BOXPLOT CON PUNTOS INDIVIDUALES
############################################################

datos_graf_03 <- datos_graf %>%
  filter(
    !is.na(situacion_laboral_cat),
    !is.na(bienestar_general)
  )

n_graf_03 <- nrow(datos_graf_03)

graf_03_boxplot <- datos_graf_03 %>%
  ggplot(aes(x = situacion_laboral_cat, y = bienestar_general, fill = situacion_laboral_cat)) +
  geom_boxplot(
    alpha = 0.75,
    outlier.shape = NA,
    width = 0.55
  ) +
  geom_jitter(
    width = 0.12,
    alpha = 0.45,
    size = 2
  ) +
  scale_y_continuous(
    limits = c(0, 10),
    breaks = 0:10
  ) +
  scale_fill_manual(values = pal_situacion_graf) +
  labs(
    title = "Bienestar general según situación laboral",
    subtitle = paste0("Boxplot con observaciones individuales. N válido = ", n_graf_03),
    x = "Situación laboral",
    y = "Bienestar general",
    caption = "Fuente: base de práctica de ayudantía."
  ) +
  theme_ayudantia() +
  theme(legend.position = "none")

graf_03_boxplot

ggsave(
  filename = "output/graficos/03_boxplot_bienestar_situacion_laboral.png",
  plot = graf_03_boxplot,
  width = 9,
  height = 5.5,
  dpi = 300
)


############################################################
# 12.4 GRÁFICO 4: DISPERSIÓN ENTRE REDES Y BIENESTAR
############################################################

datos_graf_04 <- datos_graf %>%
  filter(
    !is.na(horas_redes_dia),
    !is.na(bienestar_general),
    !is.na(situacion_laboral_cat)
  )

n_graf_04 <- nrow(datos_graf_04)

graf_04_dispersion <- datos_graf_04 %>%
  ggplot(aes(x = horas_redes_dia, y = bienestar_general)) +
  geom_point(
    aes(color = situacion_laboral_cat),
    alpha = 0.70,
    size = 2.4
  ) +
  geom_smooth(
    aes(group = 1),
    method = "lm",
    se = FALSE,
    color = "black",
    linewidth = 0.9
  ) +
  scale_x_continuous(
    limits = c(0, 16),
    breaks = seq(0, 16, 2)
  ) +
  scale_y_continuous(
    limits = c(0, 10),
    breaks = 0:10
  ) +
  scale_color_manual(values = pal_situacion_graf) +
  labs(
    title = "Horas en redes y bienestar general",
    subtitle = paste0("Relación descriptiva general. N válido = ", n_graf_04),
    x = "Horas diarias en redes",
    y = "Bienestar general",
    color = "Situación laboral",
    caption = "Fuente: base de práctica de ayudantía."
  ) +
  theme_ayudantia()

graf_04_dispersion

ggsave(
  filename = "output/graficos/04_dispersion_redes_bienestar.png",
  plot = graf_04_dispersion,
  width = 9,
  height = 5.5,
  dpi = 300
)


############################################################
# 12.5 GRÁFICO 5: BARRAS AGRUPADAS
############################################################

datos_graf_05 <- datos_graf %>%
  filter(
    !is.na(carga_movilidad_tiempo),
    !is.na(bienestar_cat)
  )

n_graf_05 <- nrow(datos_graf_05)

graf_05_barras_agrupadas <- datos_graf_05 %>%
  count(carga_movilidad_tiempo, bienestar_cat) %>%
  group_by(carga_movilidad_tiempo) %>%
  mutate(
    porcentaje = n / sum(n),
    etiqueta = percent(porcentaje, accuracy = 0.1)
  ) %>%
  ungroup() %>%
  ggplot(aes(x = bienestar_cat, y = porcentaje, fill = carga_movilidad_tiempo)) +
  geom_col(
    position = position_dodge(width = 0.8),
    width = 0.7
  ) +
  geom_text(
    aes(label = etiqueta),
    position = position_dodge(width = 0.8),
    vjust = -0.35,
    size = 3.8
  ) +
  scale_y_continuous(
    labels = percent_format(),
    limits = c(0, NA),
    expand = expansion(mult = c(0, 0.15))
  ) +
  scale_fill_manual(values = pal_carga_graf) +
  labs(
    title = "Bienestar general según carga cotidiana",
    subtitle = paste0("Porcentajes calculados dentro de cada grupo de carga. N válido = ", n_graf_05),
    x = "Nivel de bienestar",
    y = "Porcentaje dentro del grupo",
    fill = "Carga cotidiana",
    caption = "Fuente: base de práctica de ayudantía."
  ) +
  theme_ayudantia()

graf_05_barras_agrupadas

ggsave(
  filename = "output/graficos/05_barras_agrupadas_bienestar_carga.png",
  plot = graf_05_barras_agrupadas,
  width = 9,
  height = 5,
  dpi = 300
)


############################################################
# 12.6 GRÁFICO 6: BOXPLOT DE HORAS DE SUEÑO SEGÚN CARGA
############################################################

datos_graf_06 <- datos_graf %>%
  filter(
    !is.na(carga_movilidad_tiempo),
    !is.na(horas_sueno)
  )

n_graf_06 <- nrow(datos_graf_06)

graf_06_sueno_carga <- datos_graf_06 %>%
  ggplot(aes(x = carga_movilidad_tiempo, y = horas_sueno, fill = carga_movilidad_tiempo)) +
  geom_boxplot(
    alpha = 0.75,
    outlier.shape = NA,
    width = 0.55
  ) +
  geom_jitter(
    width = 0.12,
    alpha = 0.45,
    size = 2
  ) +
  scale_y_continuous(
    limits = c(0, 14),
    breaks = seq(0, 14, 2)
  ) +
  scale_fill_manual(values = pal_carga_graf) +
  labs(
    title = "Horas de sueño según carga cotidiana",
    subtitle = paste0("Comparación descriptiva entre grupos. N válido = ", n_graf_06),
    x = "Carga cotidiana",
    y = "Horas de sueño diario",
    caption = "Fuente: base de práctica de ayudantía."
  ) +
  theme_ayudantia() +
  theme(legend.position = "none")

graf_06_sueno_carga

ggsave(
  filename = "output/graficos/06_boxplot_sueno_carga.png",
  plot = graf_06_sueno_carga,
  width = 8,
  height = 5,
  dpi = 300
)


############################################################
# 12.7 GRÁFICO 7: DISPERSIÓN ENTRE TRASLADO Y BIENESTAR
############################################################

datos_graf_07 <- datos_graf %>%
  filter(
    !is.na(tiempo_traslado_min),
    !is.na(bienestar_general),
    !is.na(genero)
  )

n_graf_07 <- nrow(datos_graf_07)

graf_07_traslado_bienestar <- datos_graf_07 %>%
  ggplot(aes(x = tiempo_traslado_min, y = bienestar_general)) +
  geom_point(
    aes(color = genero),
    alpha = 0.70,
    size = 2.4
  ) +
  geom_smooth(
    aes(group = 1),
    method = "lm",
    se = FALSE,
    color = "black",
    linewidth = 0.9
  ) +
  scale_x_continuous(
    limits = c(0, 240),
    breaks = seq(0, 240, 30)
  ) +
  scale_y_continuous(
    limits = c(0, 10),
    breaks = 0:10
  ) +
  labs(
    title = "Tiempo de traslado y bienestar general",
    subtitle = paste0("Relación descriptiva general. N válido = ", n_graf_07),
    x = "Tiempo de traslado, en minutos",
    y = "Bienestar general",
    color = "Género",
    caption = "Fuente: base de práctica de ayudantía."
  ) +
  theme_ayudantia()

graf_07_traslado_bienestar

ggsave(
  filename = "output/graficos/07_dispersion_traslado_bienestar_genero.png",
  plot = graf_07_traslado_bienestar,
  width = 9,
  height = 5.5,
  dpi = 300
)


############################################################
# 12.8 GRÁFICO 8: PANEL RESUMEN
############################################################

panel_galeria <- (graf_01_barras + graf_02_histograma) /
  (graf_03_boxplot + graf_04_dispersion) +
  plot_annotation(
    title = "Galería breve de visualizaciones",
    subtitle = "Visualizaciones con rangos válidos y N informado en cada gráfico",
    caption = "Fuente: base de práctica de ayudantía."
  )

panel_galeria

ggsave(
  filename = "output/graficos/08_panel_galeria_visualizaciones.png",
  plot = panel_galeria,
  width = 12,
  height = 9,
  dpi = 300
)
############################################################
# 12.8 GRÁFICO 8: PANEL RESUMEN
############################################################

panel_galeria <- (graf_01_barras + graf_02_histograma) /
  (graf_03_boxplot + graf_04_dispersion) +
  plot_annotation(
    title = "Galería breve de visualizaciones",
    subtitle = "Situación laboral, bienestar, redes y carga cotidiana",
    caption = "Fuente: base de práctica de ayudantía."
  )

panel_galeria

ggsave(
  filename = "output/graficos/08_panel_galeria_visualizaciones.png",
  plot = panel_galeria,
  width = 12,
  height = 9,
  dpi = 300
)


############################################################
# 13. REVISAR ARCHIVOS EXPORTADOS
############################################################

list.files("output/tablas", recursive = TRUE)
list.files("output/graficos")


############################################################
# FIN DEL SCRIPT
############################################################