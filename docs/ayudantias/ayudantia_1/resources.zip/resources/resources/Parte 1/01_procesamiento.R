############################################################
# PROCESAMIENTO Y VISUALIZACIÓN DE DATOS EN R
# AYUDANTÍA 1 - PARTE II
#
# Script 03:
# MAQUETA DE ANÁLISIS DESCRIPTIVO EN R
#
# Tema de práctica:
# Movilidad cotidiana, uso del tiempo, bienestar y participación
# social en personas adultas.
#
# Objetivo del script:
# Este archivo funciona como una plantilla comentada para
# aprender a organizar un análisis descriptivo en R.
#
# No está pensado solo como una “solución” de una base específica.
# La idea es que sirva como maqueta reutilizable para futuros trabajos.
#
# En este script se hace lo siguiente:
# 1. Se genera una base simulada desde cero.
# 2. Se guarda la base como CSV.
# 3. Se carga la base desde el archivo guardado.
# 4. Se explora, limpia y recodifica.
# 5. Se calculan frecuencias, descriptivos y comparaciones.
# 6. Se hacen gráficos básicos.
# 7. Se guardan resultados.
############################################################


############################################################
# 0. IDENTIFICACIÓN DEL SCRIPT
############################################################

#


############################################################
# 1. PREPARAR EL ENTORNO DE TRABAJO
############################################################

# El entorno de trabajo es el espacio donde R guarda los objetos
# que vamos creando: bases, tablas, gráficos, funciones, etc.
#
# Limpiar el entorno ayuda a evitar confusiones con objetos creados
# en sesiones anteriores.
#
# Ojo:
# Si estás trabajando de forma exploratoria y tienes objetos que no
# quieres perder, no ejecutes esta línea automáticamente.

rm(list = ls())

# Evita que R muestre números en notación científica.
# Por ejemplo, muestra 1000000 en vez de 1e+06.

options(scipen = 999)


############################################################
# 2. CARGAR PAQUETES
############################################################

# Un paquete es un conjunto de funciones.
#
# Instalar un paquete:
# se hace una vez en el computador.
#
# Cargar un paquete:
# se hace cada vez que abrimos una nueva sesión de R.
#
# pacman::p_load() instala los paquetes si faltan
# y los carga si ya están instalados.

if (!require(pacman)) {
  install.packages("pacman")
}

pacman::p_load(
  tidyverse, # importar, ordenar y graficar datos
  dplyr,     # select(), filter(), mutate(), summarise()
  ggplot2,   # visualización de datos
  psych,     # descriptivos estadísticos
  sjmisc     # frecuencias simples
)

# Nota:
# Si aparece un error como:
# "there is no package called 'tidyverse'"
# significa que el paquete no está instalado.
#
# También puedes usar funciones indicando su paquete:
# readr::read_csv()
# dplyr::select()
# psych::describe()


############################################################
# 3. ORDENAR CARPETAS DEL PROYECTO
############################################################

# Un flujo reproducible implica ordenar los archivos.
#
# input/data/       : datos originales o de entrada
# output/           : resultados producidos por el análisis
# output/tablas/    : tablas exportadas
# output/graficos/  : gráficos exportados
#
# Conviene trabajar con rutas relativas:
# "input/data/base.csv"
#
# Y evitar rutas absolutas como:
# "C:/Users/Nombre/Desktop/base.csv"
#
# Las rutas relativas permiten compartir el proyecto más fácilmente.

dir.create("input", showWarnings = FALSE)
dir.create("input/data", showWarnings = FALSE, recursive = TRUE)
dir.create("output", showWarnings = FALSE)
dir.create("output/tablas", showWarnings = FALSE, recursive = TRUE)
dir.create("output/graficos", showWarnings = FALSE, recursive = TRUE)


############################################################
# 4. CREAR UNA BASE SIMULADA
############################################################

# En esta sección generamos una base ficticia.
#
# ¿Por qué simular datos?
# Porque permite practicar sin depender de una base real.
# Además, podemos introducir errores intencionales para aprender
# a detectar y limpiar valores problemáticos.
#
# set.seed() fija la semilla de aleatoriedad.
# Esto hace que a todas las personas les salga la misma base.

set.seed(2026)

# Número de casos simulados.
# Cada fila será una persona encuestada.

n <- 180

# Creamos algunas variables auxiliares para que la base sea más realista.

zona_raw <- sample(
  x = c(1, 2, 3, -99),
  size = n,
  replace = TRUE,
  prob = c(0.45, 0.35, 0.17, 0.03)
)

situacion_raw <- sample(
  x = c(1, 2, 3, 4, -99),
  size = n,
  replace = TRUE,
  prob = c(0.45, 0.18, 0.25, 0.09, 0.03)
)

transporte_raw <- sample(
  x = c(1, 2, 3, 4, 5, -99),
  size = n,
  replace = TRUE,
  prob = c(0.30, 0.28, 0.18, 0.14, 0.07, 0.03)
)

# Base simulada.
# Incluye valores problemáticos como -99, 999 y rangos imposibles.

datos_simulados <- tibble(
  id = 1:n,
  
  edad = sample(
    x = c(18:70, 999),
    size = n,
    replace = TRUE,
    prob = c(rep(1, 53), 0.04)
  ),
  
  genero = sample(
    x = c("Mujer", "Hombre", "Otro / Prefiere no decir"),
    size = n,
    replace = TRUE,
    prob = c(0.54, 0.42, 0.04)
  ),
  
  zona_residencia = zona_raw,
  
  situacion_laboral = situacion_raw,
  
  transporte_principal = transporte_raw,
  
  tiempo_traslado_min = round(rnorm(n, mean = 52, sd = 28), 0),
  
  horas_sueno = round(rnorm(n, mean = 6.8, sd = 1.2), 1),
  
  actividad_fisica_sem = round(rnorm(n, mean = 3.2, sd = 2.1), 1),
  
  horas_redes_dia = round(rnorm(n, mean = 3.4, sd = 1.7), 1),
  
  participacion_social = sample(
    x = c(1, 2, 3, 4, 5, -99),
    size = n,
    replace = TRUE,
    prob = c(0.18, 0.24, 0.28, 0.18, 0.09, 0.03)
  ),
  
  confianza_vecinal = sample(
    x = c(1, 2, 3, 4, 5, -99),
    size = n,
    replace = TRUE,
    prob = c(0.10, 0.18, 0.32, 0.25, 0.12, 0.03)
  ),
  
  estres_cotidiano = sample(
    x = c(1, 2, 3, 4, 5, -99),
    size = n,
    replace = TRUE,
    prob = c(0.07, 0.16, 0.34, 0.29, 0.11, 0.03)
  ),
  
  bienestar_general = round(rnorm(n, mean = 6.5, sd = 1.6), 1),
  
  satisfaccion_tiempo_libre = sample(
    x = c(1, 2, 3, 4, 5, -99),
    size = n,
    replace = TRUE,
    prob = c(0.09, 0.18, 0.30, 0.27, 0.13, 0.03)
  )
)

# Ajustamos algunas variables para que tengan valores plausibles.

datos_simulados$tiempo_traslado_min <- pmax(datos_simulados$tiempo_traslado_min, 0)
datos_simulados$actividad_fisica_sem <- pmax(datos_simulados$actividad_fisica_sem, 0)
datos_simulados$horas_redes_dia <- pmax(datos_simulados$horas_redes_dia, 0)
datos_simulados$bienestar_general <- pmin(pmax(datos_simulados$bienestar_general, 0), 10)

# Introducimos errores intencionales para practicar limpieza.
# Estos errores simulan problemas comunes en bases reales.

datos_simulados$tiempo_traslado_min[c(12, 77)] <- 999
datos_simulados$horas_sueno[c(20)] <- 15
datos_simulados$horas_sueno[c(44)] <- -99
datos_simulados$actividad_fisica_sem[c(33)] <- -99
datos_simulados$horas_redes_dia[c(55)] <- 18
datos_simulados$bienestar_general[c(66)] <- 999
datos_simulados$bienestar_general[c(90)] <- -2

# Guardamos la base simulada.
# Este paso permite practicar la carga de datos desde un archivo real.

write_csv(
  datos_simulados,
  "input/data/base_practica_movilidad_bienestar.csv"
)


############################################################
# 5. CARGAR LA BASE DE DATOS
############################################################

# En R, un objeto es algo que guardamos con un nombre.
#
# Ejemplo:
# datos <- read_csv("archivo.csv")
#
# Esto significa:
# “lee este archivo y guárdalo en un objeto llamado datos”.
#
# El símbolo <- se usa para asignar.
#
# read_csv() sirve para cargar archivos CSV.

archivo_datos <- "input/data/base_practica_movilidad_bienestar.csv"

# Si tu base tiene otro nombre, modifica la línea anterior.
# Ejemplo:
# archivo_datos <- "input/data/mi_base.csv"

datos <- read_csv(archivo_datos)

# Revisión inicial:
# datos muestra una vista resumida de la base en consola.
# spec(datos) muestra cómo R interpretó los tipos de columnas.

datos

spec(datos)


############################################################
# 6. EXPLORAR LA BASE ANTES DE LIMPIAR
############################################################

# Antes de limpiar datos, siempre hay que mirar la base.
# No conviene recodificar ni eliminar valores sin saber
# cómo vienen registradas las variables.

# View() permite ver la base como planilla en RStudio.
# Usamos if (interactive()) para evitar problemas si el script
# se ejecuta fuera de RStudio.

if (interactive()) {
  View(datos)
}

# names() muestra los nombres de las variables.

names(datos)

# dim() muestra filas y columnas.
# Primer número: filas.
# Segundo número: columnas.

dim(datos)

# str() muestra la estructura de la base:
# tipo de objeto, variables y tipos de datos.

str(datos)

# summary() resume las variables.
# Sirve para detectar mínimos, máximos, NA y valores raros.

summary(datos)

# Preguntas guía:
#
# ¿Cuántas filas tiene la base?
# ¿Cuántas columnas tiene?
# ¿Qué variables parecen numéricas?
# ¿Qué variables parecen categóricas?
# ¿Qué variables parecen ordinales?
# ¿Qué valores problemáticos aparecen?
# ¿Hay códigos como -99, 999 u otros valores fuera de rango?


############################################################
# 7. SELECCIONAR VARIABLES DE INTERÉS
############################################################

# select() permite quedarnos solo con las variables necesarias.
#
# Es buena práctica crear una nueva base procesada, por ejemplo
# datos_proc, y NO modificar directamente la base original datos.
#
# Así siempre podemos volver a la base inicial si cometemos un error.

datos_proc <- datos %>%
  select(
    id,
    edad,
    genero,
    zona_residencia,
    situacion_laboral,
    transporte_principal,
    tiempo_traslado_min,
    horas_sueno,
    actividad_fisica_sem,
    horas_redes_dia,
    participacion_social,
    confianza_vecinal,
    estres_cotidiano,
    bienestar_general,
    satisfaccion_tiempo_libre
  )

# Revisar nombres después de seleccionar.

names(datos_proc)

# Para renombrar una variable dentro de select(), se usa:
#
# nuevo_nombre = nombre_original
#
# Ejemplo:
#
# datos_proc <- datos %>%
#   select(
#     id,
#     bienestar = bienestar_general
#   )

# Errores comunes:
#
# Error: object 'datos' not found
# Posible causa: no cargaste la base o no ejecutaste el bloque anterior.
#
# Error: Can't select columns that don't exist
# Posible causa: escribiste mal el nombre de una variable.
#
# Solución:
# revisar names(datos).


############################################################
# 8. LIMPIAR VALORES PERDIDOS Y FUERA DE RANGO
############################################################

# Un valor perdido es un dato no disponible.
#
# En R, los valores perdidos deben estar como NA.
#
# Pero muchas bases usan códigos especiales:
# -99 = No responde
# 999 = valor perdido, imposible o mal registrado
#
# Esos códigos NO son NA automáticamente.
# Hay que convertirlos.
#
# No conviene usar na.omit() sin pensar, porque elimina filas
# completas y puede borrar información útil.
#
# Una mejor práctica inicial es limpiar variable por variable,
# según reglas claras y justificables.

datos_proc <- datos_proc %>%
  mutate(
    
    # mutate() crea o modifica variables.
    # case_when() permite escribir reglas condicionales.
    #
    # Estructura:
    # condicion ~ resultado
    #
    # TRUE ~ resultado_final significa:
    # “en todos los demás casos”.
    
    edad = case_when(
      edad == 999 ~ NA_real_,
      edad < 18 ~ NA_real_,
      edad > 100 ~ NA_real_,
      TRUE ~ as.numeric(edad)
    ),
    
    zona_residencia = case_when(
      zona_residencia == -99 ~ NA_real_,
      TRUE ~ as.numeric(zona_residencia)
    ),
    
    situacion_laboral = case_when(
      situacion_laboral == -99 ~ NA_real_,
      TRUE ~ as.numeric(situacion_laboral)
    ),
    
    transporte_principal = case_when(
      transporte_principal == -99 ~ NA_real_,
      TRUE ~ as.numeric(transporte_principal)
    ),
    
    tiempo_traslado_min = case_when(
      tiempo_traslado_min == 999 ~ NA_real_,
      tiempo_traslado_min < 0 ~ NA_real_,
      tiempo_traslado_min > 240 ~ NA_real_,
      TRUE ~ as.numeric(tiempo_traslado_min)
    ),
    
    horas_sueno = case_when(
      horas_sueno == -99 ~ NA_real_,
      horas_sueno < 0 ~ NA_real_,
      horas_sueno > 12 ~ NA_real_,
      TRUE ~ as.numeric(horas_sueno)
    ),
    
    actividad_fisica_sem = case_when(
      actividad_fisica_sem == -99 ~ NA_real_,
      actividad_fisica_sem < 0 ~ NA_real_,
      actividad_fisica_sem > 30 ~ NA_real_,
      TRUE ~ as.numeric(actividad_fisica_sem)
    ),
    
    horas_redes_dia = case_when(
      horas_redes_dia == -99 ~ NA_real_,
      horas_redes_dia < 0 ~ NA_real_,
      horas_redes_dia > 14 ~ NA_real_,
      TRUE ~ as.numeric(horas_redes_dia)
    ),
    
    participacion_social = case_when(
      participacion_social == -99 ~ NA_real_,
      participacion_social < 1 ~ NA_real_,
      participacion_social > 5 ~ NA_real_,
      TRUE ~ as.numeric(participacion_social)
    ),
    
    confianza_vecinal = case_when(
      confianza_vecinal == -99 ~ NA_real_,
      confianza_vecinal < 1 ~ NA_real_,
      confianza_vecinal > 5 ~ NA_real_,
      TRUE ~ as.numeric(confianza_vecinal)
    ),
    
    estres_cotidiano = case_when(
      estres_cotidiano == -99 ~ NA_real_,
      estres_cotidiano < 1 ~ NA_real_,
      estres_cotidiano > 5 ~ NA_real_,
      TRUE ~ as.numeric(estres_cotidiano)
    ),
    
    bienestar_general = case_when(
      bienestar_general == 999 ~ NA_real_,
      bienestar_general < 0 ~ NA_real_,
      bienestar_general > 10 ~ NA_real_,
      TRUE ~ as.numeric(bienestar_general)
    ),
    
    satisfaccion_tiempo_libre = case_when(
      satisfaccion_tiempo_libre == -99 ~ NA_real_,
      satisfaccion_tiempo_libre < 1 ~ NA_real_,
      satisfaccion_tiempo_libre > 5 ~ NA_real_,
      TRUE ~ as.numeric(satisfaccion_tiempo_libre)
    )
  )

# Mini glosario:
#
# NA_real_:
# NA para variables numéricas.
#
# NA_character_:
# NA para variables de texto.
#
# as.numeric():
# convierte una variable a formato numérico.
#
# TRUE ~:
# regla final para todos los casos no cubiertos antes.

# Chequeo posterior:
# Volvemos a revisar si quedan valores raros.

summary(datos_proc)


############################################################
# 9. RECODIFICAR VARIABLES
############################################################

# Recodificar significa transformar códigos en categorías legibles.
#
# Ejemplo:
# 1 = Urbana central
# 2 = Urbana periférica
# 3 = Rural o semiurbana
#
# Esto ayuda a interpretar tablas y gráficos.
#
# Variable nominal:
# categorías sin orden jerárquico.
# Ejemplo: género, zona, transporte principal.
#
# Variable ordinal:
# categorías con orden.
# Ejemplo: Muy bajo, Bajo, Medio, Alto, Muy alto.
#
# factor() permite definir el orden de las categorías.

datos_proc <- datos_proc %>%
  mutate(
    zona_cat = case_when(
      zona_residencia == 1 ~ "Urbana central",
      zona_residencia == 2 ~ "Urbana periférica",
      zona_residencia == 3 ~ "Rural o semiurbana",
      TRUE ~ NA_character_
    ),
    
    situacion_laboral_cat = case_when(
      situacion_laboral == 1 ~ "Trabaja jornada completa",
      situacion_laboral == 2 ~ "Trabaja jornada parcial",
      situacion_laboral == 3 ~ "Estudia",
      situacion_laboral == 4 ~ "Otra situación",
      TRUE ~ NA_character_
    ),
    
    transporte_cat = case_when(
      transporte_principal == 1 ~ "Transporte público",
      transporte_principal == 2 ~ "Automóvil",
      transporte_principal == 3 ~ "Caminata o bicicleta",
      transporte_principal == 4 ~ "Transporte compartido",
      transporte_principal == 5 ~ "No se traslada",
      TRUE ~ NA_character_
    ),
    
    participacion_cat = case_when(
      participacion_social == 1 ~ "Muy baja",
      participacion_social == 2 ~ "Baja",
      participacion_social == 3 ~ "Media",
      participacion_social == 4 ~ "Alta",
      participacion_social == 5 ~ "Muy alta",
      TRUE ~ NA_character_
    ),
    
    confianza_cat = case_when(
      confianza_vecinal == 1 ~ "Muy baja",
      confianza_vecinal == 2 ~ "Baja",
      confianza_vecinal == 3 ~ "Media",
      confianza_vecinal == 4 ~ "Alta",
      confianza_vecinal == 5 ~ "Muy alta",
      TRUE ~ NA_character_
    ),
    
    estres_cat = case_when(
      estres_cotidiano == 1 ~ "Muy bajo",
      estres_cotidiano == 2 ~ "Bajo",
      estres_cotidiano == 3 ~ "Medio",
      estres_cotidiano == 4 ~ "Alto",
      estres_cotidiano == 5 ~ "Muy alto",
      TRUE ~ NA_character_
    ),
    
    satisfaccion_tiempo_cat = case_when(
      satisfaccion_tiempo_libre == 1 ~ "Muy baja",
      satisfaccion_tiempo_libre == 2 ~ "Baja",
      satisfaccion_tiempo_libre == 3 ~ "Media",
      satisfaccion_tiempo_libre == 4 ~ "Alta",
      satisfaccion_tiempo_libre == 5 ~ "Muy alta",
      TRUE ~ NA_character_
    )
  )

# Ordenamos las categorías.
# Esto es especialmente importante para gráficos y tablas.

datos_proc <- datos_proc %>%
  mutate(
    zona_cat = factor(
      zona_cat,
      levels = c("Urbana central", "Urbana periférica", "Rural o semiurbana")
    ),
    
    situacion_laboral_cat = factor(
      situacion_laboral_cat,
      levels = c(
        "Trabaja jornada completa",
        "Trabaja jornada parcial",
        "Estudia",
        "Otra situación"
      )
    ),
    
    transporte_cat = factor(
      transporte_cat,
      levels = c(
        "Transporte público",
        "Automóvil",
        "Caminata o bicicleta",
        "Transporte compartido",
        "No se traslada"
      )
    ),
    
    participacion_cat = factor(
      participacion_cat,
      levels = c("Muy baja", "Baja", "Media", "Alta", "Muy alta"),
      ordered = TRUE
    ),
    
    confianza_cat = factor(
      confianza_cat,
      levels = c("Muy baja", "Baja", "Media", "Alta", "Muy alta"),
      ordered = TRUE
    ),
    
    estres_cat = factor(
      estres_cat,
      levels = c("Muy bajo", "Bajo", "Medio", "Alto", "Muy alto"),
      ordered = TRUE
    ),
    
    satisfaccion_tiempo_cat = factor(
      satisfaccion_tiempo_cat,
      levels = c("Muy baja", "Baja", "Media", "Alta", "Muy alta"),
      ordered = TRUE
    )
  )

# Revisar estructura después de recodificar.

str(datos_proc)


############################################################
# 10. CREAR VARIABLES NUEVAS
############################################################

# Crear una variable nueva permite traducir una idea conceptual
# en una variable observable.
#
# Ejemplo conceptual:
# “alta carga cotidiana”.
#
# Traducción en código:
# una persona tiene alta carga si cumple al menos una condición:
# - más de 90 minutos diarios de traslado;
# - menos de 6 horas de sueño;
# - más de 5 horas diarias en redes.
#
# Los puntos de corte deben justificarse en el informe.

datos_proc <- datos_proc %>%
  mutate(
    carga_movilidad_tiempo = case_when(
      tiempo_traslado_min > 90 |
        horas_sueno < 6 |
        horas_redes_dia > 5 ~ "Alta carga cotidiana",
      
      !is.na(tiempo_traslado_min) |
        !is.na(horas_sueno) |
        !is.na(horas_redes_dia) ~ "Carga moderada o baja",
      
      TRUE ~ NA_character_
    ),
    
    bienestar_cat = case_when(
      bienestar_general < 5 ~ "Bienestar bajo",
      bienestar_general >= 5 & bienestar_general < 7 ~ "Bienestar medio",
      bienestar_general >= 7 ~ "Bienestar alto",
      TRUE ~ NA_character_
    ),
    
    actividad_fisica_cat = case_when(
      actividad_fisica_sem == 0 ~ "Sin actividad física",
      actividad_fisica_sem > 0 & actividad_fisica_sem < 3 ~ "Actividad baja",
      actividad_fisica_sem >= 3 ~ "Actividad moderada o alta",
      TRUE ~ NA_character_
    )
  )

# Símbolos importantes:
#
# | significa “o”.
# Ejemplo:
# condicion_1 | condicion_2
#
# & significa “y”.
# Ejemplo:
# condicion_1 & condicion_2
#
# !is.na(variable) significa que la variable NO está perdida.
#
# TRUE ~ NA_character_ deja como NA todo lo que no entra
# en las reglas anteriores.

datos_proc <- datos_proc %>%
  mutate(
    carga_movilidad_tiempo = factor(
      carga_movilidad_tiempo,
      levels = c("Carga moderada o baja", "Alta carga cotidiana")
    ),
    
    bienestar_cat = factor(
      bienestar_cat,
      levels = c("Bienestar bajo", "Bienestar medio", "Bienestar alto"),
      ordered = TRUE
    ),
    
    actividad_fisica_cat = factor(
      actividad_fisica_cat,
      levels = c(
        "Sin actividad física",
        "Actividad baja",
        "Actividad moderada o alta"
      ),
      ordered = TRUE
    )
  )

# Revisión rápida de las nuevas variables.

table(datos_proc$carga_movilidad_tiempo, useNA = "ifany")
table(datos_proc$bienestar_cat, useNA = "ifany")
table(datos_proc$actividad_fisica_cat, useNA = "ifany")


############################################################
# 11. FRECUENCIAS Y PORCENTAJES
############################################################

# Las frecuencias sirven para describir variables categóricas.
#
# Frecuencia absoluta:
# número de casos en cada categoría.
#
# Frecuencia relativa:
# proporción de casos en cada categoría.
#
# Porcentaje:
# frecuencia relativa multiplicada por 100.

# Forma 1: R base.
# Es rápida para revisar una variable.

table(datos_proc$zona_cat)

# Forma 2: porcentaje con prop.table().

prop.table(table(datos_proc$zona_cat)) * 100

# Forma 3: tidyverse.
# Esta forma es más útil para generar tablas exportables.

tabla_zona <- datos_proc %>%
  filter(!is.na(zona_cat)) %>%
  count(zona_cat) %>%
  mutate(
    porcentaje = n / sum(n) * 100,
    porcentaje = round(porcentaje, 1)
  )

tabla_zona

# Función reutilizable:
# Sirve para calcular frecuencias sin repetir código.
#
# {{ variable }} permite usar nombres de variables dentro
# de una función.

tabla_frecuencia <- function(base, variable) {
  base %>%
    filter(!is.na({{ variable }})) %>%
    count({{ variable }}) %>%
    mutate(
      porcentaje = n / sum(n) * 100,
      porcentaje = round(porcentaje, 1)
    )
}

# Ejemplos de uso:

tabla_frecuencia(datos_proc, situacion_laboral_cat)
tabla_frecuencia(datos_proc, transporte_cat)
tabla_frecuencia(datos_proc, estres_cat)
tabla_frecuencia(datos_proc, carga_movilidad_tiempo)
tabla_frecuencia(datos_proc, bienestar_cat)


############################################################
# 12. DESCRIPTIVOS NUMÉRICOS
############################################################

# Los descriptivos numéricos se usan para variables cuantitativas.
#
# Ejemplos:
# edad, horas_sueno, tiempo_traslado_min, bienestar_general.

# Media:
# promedio de la variable.

mean(datos_proc$bienestar_general, na.rm = TRUE)

# Mediana:
# valor central de la distribución.

median(datos_proc$bienestar_general, na.rm = TRUE)

# Desviación estándar:
# indica qué tan dispersos están los datos respecto a la media.

sd(datos_proc$bienestar_general, na.rm = TRUE)

# Varianza:
# otra medida de dispersión.

var(datos_proc$bienestar_general, na.rm = TRUE)

# Rango:
# mínimo y máximo.

range(datos_proc$bienestar_general, na.rm = TRUE)

# Cuartiles:
# dividen la distribución en partes.
# .25 = primer cuartil
# .50 = mediana
# .75 = tercer cuartil

quantile(
  datos_proc$bienestar_general,
  probs = c(.25, .50, .75),
  na.rm = TRUE
)

# Resumen general.

summary(datos_proc$bienestar_general)

# Descriptivos más completos con psych.

psych::describe(datos_proc$bienestar_general)

# Importante:
# na.rm = TRUE significa “remover NA para calcular”.
#
# Si no usamos na.rm = TRUE, funciones como mean()
# pueden devolver NA cuando hay valores perdidos.

# Tabla resumida para varias variables.
# Este formato es útil para informes.

tabla_descriptivos <- datos_proc %>%
  summarise(
    media_bienestar = mean(bienestar_general, na.rm = TRUE),
    mediana_bienestar = median(bienestar_general, na.rm = TRUE),
    sd_bienestar = sd(bienestar_general, na.rm = TRUE),
    
    media_sueno = mean(horas_sueno, na.rm = TRUE),
    mediana_sueno = median(horas_sueno, na.rm = TRUE),
    sd_sueno = sd(horas_sueno, na.rm = TRUE),
    
    media_traslado = mean(tiempo_traslado_min, na.rm = TRUE),
    media_redes = mean(horas_redes_dia, na.rm = TRUE),
    media_actividad_fisica = mean(actividad_fisica_sem, na.rm = TRUE)
  ) %>%
  mutate(across(where(is.numeric), ~ round(.x, 2)))

tabla_descriptivos

# Consejo:
# Conviene mirar media y mediana juntas.
# Si son muy distintas, puede haber asimetría o valores extremos.


############################################################
# 13. COMPARAR GRUPOS CON group_by() Y summarise()
############################################################

# group_by() agrupa la base según una variable.
#
# summarise() calcula indicadores dentro de cada grupo.
#
# Esta combinación es clave para análisis descriptivo bivariado.
#
# Bivariado significa que miramos la relación descriptiva
# entre dos variables.
#
# Importante:
# Comparar grupos NO es lo mismo que probar causalidad.

tabla_carga_resumen <- datos_proc %>%
  filter(!is.na(carga_movilidad_tiempo)) %>%
  group_by(carga_movilidad_tiempo) %>%
  summarise(
    n = n(),
    media_traslado = mean(tiempo_traslado_min, na.rm = TRUE),
    media_sueno = mean(horas_sueno, na.rm = TRUE),
    media_redes = mean(horas_redes_dia, na.rm = TRUE),
    media_estres = mean(estres_cotidiano, na.rm = TRUE),
    media_bienestar = mean(bienestar_general, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(across(where(is.numeric), ~ round(.x, 2)))

tabla_carga_resumen

# n = n() cuenta casos dentro de cada grupo.
#
# .groups = "drop" indica que la tabla final ya no debe
# quedar agrupada.
#
# Preguntas para interpretar:
#
# ¿Qué grupo tiene mayor bienestar promedio?
# ¿Qué grupo tiene mayor estrés promedio?
# ¿Qué grupo duerme menos?
# ¿Las diferencias observadas son descriptivas o causales?

# Segundo ejemplo:
# comparar según transporte principal.

tabla_transporte_resumen <- datos_proc %>%
  filter(!is.na(transporte_cat)) %>%
  group_by(transporte_cat) %>%
  summarise(
    n = n(),
    media_traslado = mean(tiempo_traslado_min, na.rm = TRUE),
    media_bienestar = mean(bienestar_general, na.rm = TRUE),
    media_estres = mean(estres_cotidiano, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(across(where(is.numeric), ~ round(.x, 2)))

tabla_transporte_resumen


############################################################
# 14. VISUALIZACIONES CON GGPLOT2
############################################################

# ggplot2 funciona por capas.
#
# Estructura básica:
#
# ggplot(base, aes(x = variable_x, y = variable_y)) +
#   geom_tipo_de_grafico() +
#   labs() +
#   theme_minimal()
#
# ggplot() crea la base del gráfico.
# aes() define qué variables se usan.
# geom_* define el tipo de gráfico.
# labs() agrega títulos y nombres de ejes.
# theme_minimal() mejora la estética general.


############################################################
# 14.1 GRÁFICO DE BARRAS
############################################################

# Se usa para variables categóricas.
# Ejemplo: distribución de carga cotidiana.

graf_carga <- ggplot(datos_proc, aes(x = carga_movilidad_tiempo)) +
  geom_bar() +
  labs(
    title = "Distribución según carga cotidiana",
    subtitle = "Frecuencia de personas según carga de movilidad y tiempo",
    x = "Carga cotidiana",
    y = "Frecuencia"
  ) +
  theme_minimal()

graf_carga


############################################################
# 14.2 HISTOGRAMA
############################################################

# Se usa para variables numéricas.
# Permite observar la forma de una distribución:
# concentración, dispersión, asimetría o valores extremos.

graf_bienestar_hist <- ggplot(datos_proc, aes(x = bienestar_general)) +
  geom_histogram(bins = 10) +
  labs(
    title = "Distribución del bienestar general",
    subtitle = "Bienestar medido en escala de 0 a 10",
    x = "Bienestar general",
    y = "Frecuencia"
  ) +
  theme_minimal()

graf_bienestar_hist


############################################################
# 14.3 BOXPLOT
############################################################

# Se usa para comparar una variable numérica entre grupos.
#
# Permite observar:
# - mediana;
# - dispersión;
# - valores extremos;
# - diferencias descriptivas entre categorías.

graf_bienestar_box <- ggplot(
  datos_proc,
  aes(x = carga_movilidad_tiempo, y = bienestar_general)
) +
  geom_boxplot() +
  labs(
    title = "Bienestar general según carga cotidiana",
    subtitle = "Comparación descriptiva entre grupos",
    x = "Carga cotidiana",
    y = "Bienestar general"
  ) +
  theme_minimal()

graf_bienestar_box

# Desafío:
# Adaptar este gráfico para comparar horas_sueno
# según carga_movilidad_tiempo.

graf_sueno_carga <- ggplot(
  datos_proc,
  aes(x = carga_movilidad_tiempo, y = horas_sueno)
) +
  geom_boxplot() +
  labs(
    title = "Horas de sueño según carga cotidiana",
    subtitle = "Comparación descriptiva entre grupos",
    x = "Carga cotidiana",
    y = "Horas de sueño"
  ) +
  theme_minimal()

graf_sueno_carga


############################################################
# 14.4 GRÁFICO DE DISPERSIÓN
############################################################

# Se usa para observar la relación entre dos variables numéricas.
#
# Importante:
# Un gráfico de dispersión muestra asociación visual.
# No prueba causalidad.

graf_dispersion <- ggplot(
  datos_proc,
  aes(x = tiempo_traslado_min, y = bienestar_general)
) +
  geom_point(alpha = 0.7) +
  geom_smooth(method = "lm", se = FALSE) +
  labs(
    title = "Tiempo de traslado y bienestar general",
    subtitle = "Relación descriptiva, no causal",
    x = "Tiempo de traslado diario en minutos",
    y = "Bienestar general"
  ) +
  theme_minimal()

graf_dispersion


############################################################
# 15. GUARDAR RESULTADOS
############################################################

# Guardar resultados permite que el análisis sea reproducible.
#
# CSV:
# formato abierto, fácil de leer en Excel, R, Python u otros programas.
#
# RData:
# formato propio de R, conserva objetos tal como están en la sesión.

write_csv(
  datos_proc,
  "output/datos_proc_final_movilidad_bienestar.csv"
)

save(
  datos_proc,
  file = "output/datos_proc_final_movilidad_bienestar.RData"
)

# Guardar tablas:
# Estas tablas pueden usarse después en informes o presentaciones.

write_csv(
  tabla_zona,
  "output/tablas/tabla_frecuencia_zona.csv"
)

write_csv(
  tabla_descriptivos,
  "output/tablas/tabla_descriptivos_generales.csv"
)

write_csv(
  tabla_carga_resumen,
  "output/tablas/tabla_resumen_por_carga.csv"
)

write_csv(
  tabla_transporte_resumen,
  "output/tablas/tabla_resumen_por_transporte.csv"
)

# Guardar gráficos:
#
# Conviene guardar el gráfico como objeto antes de exportarlo.
# Así podemos verlo, corregirlo y luego guardarlo.
#
# width  = ancho
# height = alto
# dpi    = resolución de la imagen

ggsave(
  filename = "output/graficos/grafico_carga_cotidiana.png",
  plot = graf_carga,
  width = 8,
  height = 5,
  dpi = 300
)

ggsave(
  filename = "output/graficos/histograma_bienestar_general.png",
  plot = graf_bienestar_hist,
  width = 8,
  height = 5,
  dpi = 300
)

ggsave(
  filename = "output/graficos/boxplot_bienestar_carga.png",
  plot = graf_bienestar_box,
  width = 8,
  height = 5,
  dpi = 300
)

ggsave(
  filename = "output/graficos/boxplot_sueno_carga.png",
  plot = graf_sueno_carga,
  width = 8,
  height = 5,
  dpi = 300
)

ggsave(
  filename = "output/graficos/dispersion_traslado_bienestar.png",
  plot = graf_dispersion,
  width = 8,
  height = 5,
  dpi = 300
)


############################################################
# 16. PREGUNTAS DE INTERPRETACIÓN
############################################################

# Responder al final del script o en un informe breve:
#
# 1. ¿Qué pregunta de investigación orientó tu análisis?
#
# 2. ¿Qué variables usaste para responderla?
#
# 3. ¿Qué valores problemáticos encontraste?
#
# 4. ¿Cómo los recodificaste?
#
# 5. ¿Qué muestran las frecuencias?
#
# 6. ¿Qué muestran los descriptivos numéricos?
#
# 7. ¿Qué diferencias aparecen entre grupos?
#
# 8. ¿Qué gráfico ayuda más a responder la pregunta?
#
# 9. ¿Qué puedes concluir descriptivamente?
#
# 10. ¿Qué NO puedes concluir?
#
# Respuesta modelo para la última pregunta:
#
# No puedo concluir causalidad. Este análisis permite describir
# diferencias entre grupos, pero no afirmar que la carga cotidiana,
# el transporte o la actividad física causen mayor o menor bienestar.


############################################################
# 17. ERRORES COMUNES EN R
############################################################

# 1. Objeto no encontrado
#
# Error:
# object 'datos_proc' not found
#
# Posible causa:
# No ejecutaste el bloque donde se crea datos_proc.
#
# Solución:
# Ejecutar el script desde el inicio o revisar el nombre del objeto.


# 2. Variable mal escrita
#
# Error:
# object 'carga_movilidad_tiemp' not found
#
# Posible causa:
# Escribiste mal el nombre de la variable.
#
# Solución:
# Usar names(datos_proc) para revisar nombres exactos.


# 3. Paquete no instalado
#
# Error:
# there is no package called 'tidyverse'
#
# Solución:
# install.packages("tidyverse")
# o usar pacman::p_load(tidyverse)


# 4. Ruta incorrecta
#
# Error:
# cannot open file
#
# Posible causa:
# El archivo no está en la carpeta indicada.
#
# Solución:
# Revisar que la base esté en input/data/
# y que el nombre del archivo esté bien escrito.


# 5. Problemas con NA
#
# Si hay NA, funciones como mean() pueden devolver NA.
#
# Ejemplo:
# mean(datos_proc$bienestar_general)
#
# Solución:
# mean(datos_proc$bienestar_general, na.rm = TRUE)


# 6. Confusión entre <-, == y =
#
# <- asigna objetos:
# datos <- read_csv("archivo.csv")
#
# == compara valores:
# edad == 999
#
# = suele usarse dentro de funciones:
# mean(x = datos_proc$bienestar_general, na.rm = TRUE)

############################################################
# FIN DEL SCRIPT
############################################################